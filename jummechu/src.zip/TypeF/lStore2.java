package TypeF;

public class lStore2 {

    private int sCode2;
    private String sName2;
    private String sTNum2;
    private String sAddr2;
    private int fCode2;
    private int mCode2;

    public int getsCode2() {
        return sCode2;
    }

    public void setsCode2(int sCode2) {
        this.sCode2 = sCode2;
    }

    public String getsName2() {
        return sName2;
    }

    public void setsName2(String sName2) {
        this.sName2 = sName2;
    }

    public String getsTNum2() {
        return sTNum2;
    }

    public void setsTNum2(String sTNum2) {
        this.sTNum2 = sTNum2;
    }

    public String getsAddr2() {
        return sAddr2;
    }

    public void setsAddr2(String sAddr2) {
        this.sAddr2 = sAddr2;
    }

    public int getfCode2() {
        return fCode2;
    }

    public void setfCode2(int fCode2) {
        this.fCode2 = fCode2;
    }

    public int getmCode2() {
        return mCode2;
    }

    public void setmCode2(int mCode2) {
        this.mCode2 = mCode2;
    }

    @Override
    public String toString() {
        return "lStore2{" +
                "sCode2=" + sCode2 +
                ", sName2='" + sName2 + '\'' +
                ", sTNum2='" + sTNum2 + '\'' +
                ", sAddr2='" + sAddr2 + '\'' +
                ", fCode2=" + fCode2 +
                ", mCode2=" + mCode2 +
                '}';
    }
}
