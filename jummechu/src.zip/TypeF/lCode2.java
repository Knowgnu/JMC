package TypeF;

public class lCode2 {

    private int fCode2;
    private String fType2;

    public int getfCode2() {
        return fCode2;
    }

    public void setfCode2(int fCode2) {
        this.fCode2 = fCode2;
    }

    public String getfType2() {
        return fType2;
    }

    public void setfType2(String fType2) {
        this.fType2 = fType2;
    }

    @Override
    public String toString() {
        return "lCode2{" +
                "fCode2=" + fCode2 +
                ", fType2='" + fType2 + '\'' +
                '}';
    }
}
