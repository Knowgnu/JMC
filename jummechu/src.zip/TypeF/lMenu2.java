package TypeF;

public class lMenu2 {

    private int mCode2;
    private String mName2;

    public int getmCode2() {
        return mCode2;
    }

    public void setmCode2(int mCode2) {
        this.mCode2 = mCode2;
    }

    public String getmName2() {
        return mName2;
    }

    public void setmName2(String mName2) {
        this.mName2 = mName2;
    }

    @Override
    public String toString() {
        return "lMenu2{" +
                "mCode2=" + mCode2 +
                ", mName2='" + mName2 + '\'' +
                '}';
    }
}
