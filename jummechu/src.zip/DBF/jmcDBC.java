package DBF;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class jmcDBC {

    public static Connection DBConnect(){

        Connection con = null ;

        String url = "jdbc:oracle:thin:@localhost:1521:xe";

        String user = "JUMMECHU";
        String password = "1111";

        try {

            Class.forName("oracle.jdbc.driver.OracleDriver");

            con = DriverManager.getConnection(url, user, password);


        } catch (ClassNotFoundException e) {
            System.out.println("DB 접속 실패 : 드라이버 로딩 실패!");
            throw new RuntimeException(e);
        } catch (SQLException e) {
            System.out.println("DB 접속 실패 : 접속 정보 확인!");
            throw new RuntimeException(e);
        }
        return con;
    }
}

